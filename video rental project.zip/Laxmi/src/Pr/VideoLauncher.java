package Pr;



import java.util.Scanner;

class Video {
    String videoName;
    boolean checkout;
    int rating;

    public Video(String name) {
        this.videoName = name;
        this.checkout = false;
        this.rating = 0;
    }

    public String getName() {
        return this.videoName;
    }

    public void doCheckout() {
        this.checkout = true;
    }

    void doReturn() {
        this.checkout = false;
    }

    public void receiveRating(int rating) {
        this.rating = rating;
    }

    public int getRating() {
        return this.rating;
    }

    public boolean getCheckout() {
        return this.checkout;
    }
}

class VideoStore {
    private Video[] store;

    public VideoStore() {
        this.store = new Video[0];
    }

    public int getStoreSize() {
        return store.length;
    }

    public Video getLastAdded() {
        if (store.length > 0) {
            return store[store.length - 1];
        }
        return null;
    }

    public void addVideo(String name) {
        Video video = new Video(name);
        Video[] newStore = new Video[store.length + 1];
        System.arraycopy(store, 0, newStore, 0, store.length);
        newStore[store.length] = video;
        store = newStore;
    }

    public void doCheckout(String name) {
        if (store.length == 0) {
            System.out.println("Store is empty");
            return;
        }

        for (Video video : store) {
            if (video.getName().equals(name)) {
                video.doCheckout();
                return;
            }
        }
        System.out.println("Video not found");
    }

    public void doReturn(String name) {
        if (store.length == 0) {
            System.out.println("Store is empty");
            return;
        }

        for (Video video : store) {
            if (video.getName().equals(name)) {
                video.doReturn();
                return;
            }
        }
        System.out.println("Video not found");
    }

    public void receiveRating(String name, int rating) {
        if (store.length == 0) {
            System.out.println("Store is empty");
            return;
        }

        for (Video video : store) {
            if (video.getName().equals(name)) {
                video.receiveRating(rating);
                return;
            }
        }
        System.out.println("Video not found");
    }

    public void listInventory() {
        if (store.length == 0) {
            System.out.println("Store is empty");
            return;
        }

        System.out.println("\n" + "-".repeat(80));
        System.out.printf("%-20s %-10s %-15s%n", "Name", "Rating", "Checkout");
        System.out.println("-".repeat(80));

        for (Video video : store) {
            System.out.printf("%-20s %-10d %-15b%n", video.getName(), video.getRating(), video.getCheckout());
        }

        System.out.println("-".repeat(80));
    }
}

public class VideoLauncher {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        VideoStore s = new VideoStore();

        int choice = 0;

        do {
            System.out.println("\n1. Add Videos\n" +
                               "2. Check Out Video\n" +
                               "3. Return Video\n" +
                               "4. Receive Rating\n" +
                               "5. List Inventory\n" +
                               "6. Exit\n" +
                               "Enter your choice (1..6): ");
            if (sc.hasNextInt()) {
                choice = sc.nextInt();
                sc.nextLine(); // Consume newline
            } else {
                sc.next(); // Consume invalid input
                choice = 6; // Exit option
            }

            String name;

            switch (choice) {
                case 1:
                    System.out.println("Enter the name of the video you want to add: ");
                    name = sc.nextLine();
                    s.addVideo(name);
                    System.out.println("Video " + name + " added successfully.");
                    break;
                case 2:
                    System.out.println("Enter the name of the video you want to check out: ");
                    name = sc.nextLine();
                    s.doCheckout(name);
                    System.out.println("Video " + name + " checked out successfully.");
                    break;
                case 3:
                    System.out.println("Enter the name of the video you want to return: ");
                    name = sc.nextLine();
                    s.doReturn(name);
                    System.out.println("Video " + name + " returned successfully.");
                    break;
                case 4:
                    System.out.println("Enter the name of the video you want to rate: ");
                    name = sc.nextLine();
                    System.out.println("Enter the rating for this video: ");
                    int rating = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    s.receiveRating(name, rating);
                    System.out.println("Rating " + rating + " has been mapped to the video " + name + ".");
                    break;
                case 5:
                    s.listInventory();
                    break;
                case 6:
                    System.out.println("Exiting...!! Thanks for using the application.");
                    break;
                default:
                    System.out.println("Invalid choice. Exiting...");
                    break;
            }
        } while (choice != 6);

        sc.close();
    }
}
